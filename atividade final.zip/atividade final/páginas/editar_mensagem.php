<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Conectar ao banco
try {
    $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
    
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
} catch (Exception $e) {
    die("<h1 style='color: red; text-align: center; margin-top: 50px;'>❌ ERRO: " . $e->getMessage() . "</h1>");
}

// Buscar mensagem para editar
$id = $_GET['id'] ?? 0;
$mensagem_data = null;

if ($id) {
    $sql = "SELECT * FROM mensagens WHERE id = $id";
    $resultado = $conexao->query($sql);
    if ($resultado->num_rows > 0) {
        $mensagem_data = $resultado->fetch_assoc();
    }
}

// Processar atualização
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $telefone = $conexao->real_escape_string($_POST['telefone']);
    $email = $conexao->real_escape_string($_POST['email']);
    $empresa = $conexao->real_escape_string($_POST['empresa']);
    $assunto = $conexao->real_escape_string($_POST['assunto']);
    $mensagem_texto = $conexao->real_escape_string($_POST['mensagem']);
    
    $sql = "UPDATE mensagens SET 
            nome = '$nome',
            telefone = '$telefone', 
            email = '$email',
            empresa = '$empresa',
            assunto = '$assunto',
            mensagem = '$mensagem_texto'
            WHERE id = $id";
    
    if ($conexao->query($sql)) {
        header("Location: painel_mensagens.php");
        exit;
    } else {
        $erro = "❌ ERRO AO ATUALIZAR: " . $conexao->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Mensagem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
        }
        .header-card {
            background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
            color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        .form-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .btn-custom {
            border-radius: 8px;
            padding: 10px 25px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- CABEÇALHO -->
        <div class="header-card">
            <h1><i class="bi bi-pencil-square me-2"></i>EDITAR MENSAGEM</h1>
            <p class="mb-0">Altere os dados da mensagem #<?php echo $id; ?></p>
        </div>

        <?php if (isset($erro)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <?php echo $erro; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($mensagem_data): ?>
        <div class="form-card">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-person me-2"></i>Nome</label>
                        <input type="text" class="form-control" name="nome" value="<?php echo $mensagem_data['nome']; ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><i class="bi bi-telephone me-2"></i>Telefone</label>
                        <input type="text" class="form-control" name="telefone" value="<?php echo $mensagem_data['telefone']; ?>">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-envelope me-2"></i>Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo $mensagem_data['email']; ?>" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-building me-2"></i>Empresa</label>
                    <input type="text" class="form-control" name="empresa" value="<?php echo $mensagem_data['empresa']; ?>">
                </div>
                
                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-chat-dots me-2"></i>Assunto</label>
                    <input type="text" class="form-control" name="assunto" value="<?php echo $mensagem_data['assunto']; ?>" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label"><i class="bi bi-chat-text me-2"></i>Mensagem</label>
                    <textarea class="form-control" name="mensagem" rows="6" required><?php echo $mensagem_data['mensagem']; ?></textarea>
                </div>
                
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success btn-custom me-3">
                        <i class="bi bi-check-circle me-2"></i>SALVAR ALTERAÇÕES
                    </button>
                    <a href="painel_mensagens.php" class="btn btn-secondary btn-custom">
                        <i class="bi bi-arrow-left me-2"></i>CANCELAR
                    </a>
                </div>
            </form>
        </div>
        <?php else: ?>
            <div class="alert alert-danger text-center">
                <i class="bi bi-exclamation-circle me-2"></i>
                Mensagem não encontrada.
            </div>
            <div class="text-center">
                <a href="painel_mensagens.php" class="btn btn-primary">Voltar ao Painel</a>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>