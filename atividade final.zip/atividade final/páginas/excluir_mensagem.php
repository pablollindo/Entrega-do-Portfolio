<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Conectar ao banco
try {
    $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
    
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
} catch (Exception $e) {
    die("<h1 style='color: red; text-align: center; margin-top: 50px;'>❌ ERRO: " . $e->getMessage() . "</h1>");
}

// Excluir mensagem
$id = $_GET['id'] ?? 0;

if ($id) {
    $sql = "DELETE FROM mensagens WHERE id = $id";
    if ($conexao->query($sql)) {
        header("Location: painel_mensagens.php");
        exit;
    } else {
        $erro = $conexao->error;
    }
} else {
    $erro = "ID não especificado";
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Mensagem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .message-card {
            background: white;
            border-radius: 15px;
            padding: 3rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 500px;
            width: 100%;
        }
        .btn-custom {
            border-radius: 8px;
            padding: 10px 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="message-card">
        <?php if (isset($erro)): ?>
            <div class="text-danger mb-4">
                <i class="bi bi-x-circle display-1"></i>
                <h2 class="mt-3">Erro ao Excluir</h2>
                <p class="text-muted"><?php echo $erro; ?></p>
            </div>
        <?php else: ?>
            <div class="text-success mb-4">
                <i class="bi bi-check-circle display-1"></i>
                <h2 class="mt-3">Mensagem Excluída!</h2>
                <p class="text-muted">A mensagem foi removida do banco de dados com sucesso.</p>
            </div>
        <?php endif; ?>
        
        <a href="painel_mensagens.php" class="btn btn-primary btn-custom">
            <i class="bi bi-speedometer2 me-2"></i>VOLTAR AO PAINEL
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>